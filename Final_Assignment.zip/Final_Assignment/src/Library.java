import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Library {
    private static final String EQUIPMENT_FILE_PATH = "equipment_data.txt";
    private static List<Equipment> equipmentList;

    public static void main(String[] args) {
        equipmentList = new ArrayList<>();
        loadEquipmentDataFromFile();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Equipment Library Menu:");
            System.out.println("1. Add Equipment");
            System.out.println("2. Search Equipment by MAC Address");
            System.out.println("3. Connect Two Equipment");
            System.out.println("4. Disconnect Two Equipment");
            System.out.println("5. Get Last Updated Equipment");
            System.out.println("6. Get Last Connected Equipment");
            System.out.println("7. Get Equipment in Location");
            System.out.println("8. Save Equipment Data to File");
            System.out.println("9. Load Equipment Data from File");
            System.out.println("10. Exit");
            System.out.print("Enter your choice (1-10): ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addEquipment(scanner); // Call the addEquipment method
                    saveEquipmentDataToFile(); // Save the equipment data to file
                    break;
                case 2:
                    searchEquipmentByMacAddress(scanner); // Call the searchEquipmentByMacAddress method
                    break;
                case 3:
                    connectTwoEquipment(scanner); // Call the connectTwoEquipment method
                    saveEquipmentDataToFile(); // Save the equipment data to file
                    break;
                case 4:
                    disconnectTwoEquipment(scanner); // Call the disconnectTwoEquipment method
                    saveEquipmentDataToFile(); // Save the equipment data to file
                    break;
                case 5:
                    Equipment lastUpdatedEquipment = getLastUpdatedEquipment(); // Get the last updated equipment
                    if (lastUpdatedEquipment != null) {
                        System.out.println("Last Updated Equipment:");
                        System.out.println(lastUpdatedEquipment);
                    } else {
                        System.out.println("No equipment found.");
                    }
                    break;
                case 6:
                    Equipment lastConnectedEquipment = getLastConnectedEquipment(); // Get the last connected equipment
                    if (lastConnectedEquipment != null) {
                        System.out.println("Last Connected Equipment:");
                        System.out.println(lastConnectedEquipment);
                    } else {
                        System.out.println("No equipment found.");
                    }
                    break;
                case 7:
                    System.out.print("Enter location: ");
                    String location = scanner.nextLine();
                    List<Equipment> equipmentsInLocation = getEquipmentInLocation(location); // Get equipment in a specific location
                    if (!equipmentsInLocation.isEmpty()) {
                        System.out.println("Equipment in " + location + ":");
                        for (Equipment equipment : equipmentsInLocation) {
                            System.out.println(equipment);
                        }
                    } else {
                        System.out.println("No equipment found in " + location + ".");
                    }
                    break;
                case 8:
                    saveEquipmentDataToFile(); // Save the equipment data to file
                    System.out.println("Equipment data saved to file successfully.");
                    break;
                case 9:
                    loadEquipmentDataFromFile(); // Load the equipment data from file
                    System.out.println("Equipment data loaded from file successfully.");
                    break;
                case 10:
                    saveEquipmentDataToFile(); // Save the equipment data to file
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Method to add new equipment
    private static void addEquipment(Scanner scanner) {
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Manufacturer: ");
        String manufacturer = scanner.nextLine();

        System.out.print("Enter Model Number: ");
        String modelNumber = scanner.nextLine();

        System.out.print("Enter Serial Number: ");
        String serialNumber = scanner.nextLine();

        System.out.print("Enter MAC Address: ");
        String macAddress = scanner.nextLine();

        System.out.print("Enter Current IP Address: ");
        String currentIPAddress = scanner.nextLine();

        System.out.print("Enter Previous IP Address: ");
        String previousIPAddress = scanner.nextLine();

        System.out.print("Enter Current Location: ");
        String currentLocation = scanner.nextLine();

        System.out.print("Enter Previous Location: ");
        String previousLocation = scanner.nextLine();

        Equipment equipment = new Equipment(name, manufacturer, modelNumber, serialNumber, macAddress,
                currentIPAddress, previousIPAddress, currentLocation, previousLocation);
        equipmentList.add(equipment);

        System.out.println("Equipment added successfully:");
        System.out.println(equipment);
    }

    // Method to search equipment by MAC address
    private static void searchEquipmentByMacAddress(Scanner scanner) {
        System.out.print("Enter MAC Address: ");
        String macAddress = scanner.nextLine();

        for (Equipment equipment : equipmentList) {
            if (equipment.getMacAddress().equals(macAddress)) {
                System.out.println("Equipment found:");
                System.out.println(equipment);
                return;
            }
        }

        System.out.println("No equipment found with MAC Address: " + macAddress);
    }

    // Method to connect two equipment
    private static void connectTwoEquipment(Scanner scanner) {
        System.out.print("Enter MAC Address of first equipment: ");
        String macAddress1 = scanner.nextLine();

        System.out.print("Enter MAC Address of second equipment: ");
        String macAddress2 = scanner.nextLine();

        // Retrieve the Equipment objects based on the provided MAC addresses
        Equipment equipment1 = getEquipmentByMacAddress(macAddress1);
        Equipment equipment2 = getEquipmentByMacAddress(macAddress2);

        if (equipment1 == null) {
            System.out.println("Equipment not found with MAC Address: " + macAddress1);
            // Return from the method as the equipment is not found
            return;
        }

        // Check if the second equipment is not found
        if (equipment2 == null) {
            // Print an error message indicating that the equipment is not found
            System.out.println("Equipment not found with MAC Address: " + macAddress2);
            // Return from the method as the equipment is not found
            return;
        }

        // Check if the first equipment is already connected
        if (equipment1.getLastConnected() != null) {
            System.out.println("Equipment with MAC Address " + macAddress1 + " is already connected.");
            return;
        }

        if (equipment2.getLastConnected() != null) {
            System.out.println("Equipment with MAC Address " + macAddress2 + " is already connected.");
            return;
        }

        // Set the last connected timestamp to the current date and time for both equipment
        equipment1.setLastConnected(new Date());
        equipment2.setLastConnected(new Date());

        System.out.println("Equipment connected successfully:");
        System.out.println("Equipment 1: " + equipment1);
        System.out.println("Equipment 2: " + equipment2);
    }

    // Method to disconnect two equipment
    private static void disconnectTwoEquipment(Scanner scanner) {
        System.out.print("Enter MAC Address of first equipment: ");
        String macAddress1 = scanner.nextLine();

        System.out.print("Enter MAC Address of second equipment: ");
        String macAddress2 = scanner.nextLine();

        Equipment equipment1 = getEquipmentByMacAddress(macAddress1);
        Equipment equipment2 = getEquipmentByMacAddress(macAddress2);

        if (equipment1 == null) {
            System.out.println("Equipment not found with MAC Address: " + macAddress1);
            return;
        }

        if (equipment2 == null) {
            System.out.println("Equipment not found with MAC Address: " + macAddress2);
            return;
        }

        equipment1.setLastConnected(null);
        equipment2.setLastConnected(null);

        System.out.println("Equipment disconnected successfully:");
        System.out.println("Equipment 1: " + equipment1);
        System.out.println("Equipment 2: " + equipment2);
    }

    // Method to get the last updated equipment
    private static Equipment getLastUpdatedEquipment() {
        Equipment lastUpdatedEquipment = null;

        for (Equipment equipment : equipmentList) {
            if (lastUpdatedEquipment == null || equipment.getLastUpdated().after(lastUpdatedEquipment.getLastUpdated())) {
                lastUpdatedEquipment = equipment;
            }
        }

        return lastUpdatedEquipment;
    }

    // Method to get the last connected equipment
    private static Equipment getLastConnectedEquipment() {
        Equipment lastConnectedEquipment = null;

        for (Equipment equipment : equipmentList) {
            if (lastConnectedEquipment == null || equipment.getLastConnected().after(lastConnectedEquipment.getLastConnected())) {
                lastConnectedEquipment = equipment;
            }
        }

        return lastConnectedEquipment;
    }

    // Method to get equipment in a specific location
    private static List<Equipment> getEquipmentInLocation(String location) {
        List<Equipment> equipmentsInLocation = new ArrayList<>();

        for (Equipment equipment : equipmentList) {
            if (equipment.getCurrentLocation().equalsIgnoreCase(location) || equipment.getPreviousLocation().equalsIgnoreCase(location)) {
                equipmentsInLocation.add(equipment);
            }
        }

        return equipmentsInLocation;
    }

    // Method to get equipment by MAC address
    private static Equipment getEquipmentByMacAddress(String macAddress) {
        for (Equipment equipment : equipmentList) {
            if (equipment.getMacAddress().equals(macAddress)) {
                return equipment;
            }
        }

        return null;
    }

    // Method to save equipment data to a file
    private static void saveEquipmentDataToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(EQUIPMENT_FILE_PATH))) {
            for (Equipment equipment : equipmentList) {
                writer.write(equipment.toString());
                writer.newLine();
            }
            System.out.println("Equipment data saved to file successfully.");
        } catch (IOException e) {
            System.out.println("Failed to save equipment data to file.");
            e.printStackTrace();
        }
    }

    // Method to load equipment data from a file
    private static void loadEquipmentDataFromFile() {
        equipmentList.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(EQUIPMENT_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Equipment equipment = deserialize(line);
                if (equipment != null) {
                    equipmentList.add(equipment);
                }
            }
            System.out.println("Equipment data loaded from file successfully.");
        } catch (IOException e) {
            System.out.println("Failed to load equipment data from file: " + e.getMessage());
        }
    }

    // Method to deserialize equipment from a string
    private static Equipment deserialize(String line) {
        String[] parts = line.split(",");
        if (parts.length == 10) {
            String name = parts[0].trim(); // trim method is used to remove any leading or trailing whitespace from each part.
            String manufacturer = parts[1].trim();
            String modelNumber = parts[2].trim();
            String serialNumber = parts[3].trim();
            String macAddress = parts[4].trim();
            String currentIPAddress = parts[5].trim();
            String previousIPAddress = parts[6].trim();
            String currentLocation = parts[7].trim();
            String previousLocation = parts[8].trim();
            String lastUpdatedString = parts[9].trim();
            Date lastUpdated = null;
            try {
                lastUpdated = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(lastUpdatedString);
            } catch (ParseException e) {
                System.out.println("Failed to parse last updated date: " + e.getMessage());
            }
            return new Equipment(name, manufacturer, modelNumber, serialNumber, macAddress,
                    currentIPAddress, previousIPAddress, currentLocation, previousLocation);
        }
        return null;
    }
}
