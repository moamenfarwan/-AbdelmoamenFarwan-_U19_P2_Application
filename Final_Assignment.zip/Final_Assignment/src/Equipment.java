import java.io.*;
import java.util.Date;

public class Equipment {
    private String name;
    private String manufacturer;
    private String modelNumber;
    private String serialNumber;
    private String macAddress;
    private String currentIPAddress;
    private String previousIPAddress;
    private String currentLocation;
    private String previousLocation;
    private Date lastUpdated;
    private Date lastConnected;

    // Making a constructor for each attribute
    public Equipment(String name, String manufacturer, String modelNumber, String serialNumber,
                     String macAddress, String ipAddress, String previousIpAddress,
                     String location, String previousLocation) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.modelNumber = modelNumber;
        this.serialNumber = serialNumber;
        this.macAddress = macAddress;
        this.currentIPAddress = ipAddress;
        this.previousIPAddress = previousIpAddress;
        this.currentLocation = location;
        this.previousLocation = previousLocation;
        this.lastUpdated = new Date();
        this.lastConnected = null;
    }

    // Getters for accessing the private fields of an Equipment
    public String getName() {
        return name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public String getCurrentIPAddress() {
        return currentIPAddress;
    }

    public String getPreviousIPAddress() {
        return previousIPAddress;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public String getPreviousLocation() {
        return previousLocation;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public Date getLastConnected() {
        return lastConnected;
    }

    public void setLastConnected(Date lastConnected) {
        this.lastConnected = lastConnected;
        this.lastUpdated = new Date();
    }

    // Load equipment data from a file
    public static Equipment loadEquipmentDataFromFile(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Reading each line of the file and assigning values to variables
            String name = reader.readLine();
            String manufacturer = reader.readLine();
            String modelNumber = reader.readLine();
            String serialNumber = reader.readLine();
            String macAddress = reader.readLine();
            String currentIPAddress = reader.readLine();
            String previousIPAddress = reader.readLine();
            String currentLocation = reader.readLine();
            String previousLocation = reader.readLine();

            // Create and return an Equipment object with the loaded data
            return new Equipment(name, manufacturer, modelNumber, serialNumber, macAddress,
                    currentIPAddress, previousIPAddress, currentLocation, previousLocation);
        }
    }

    // Save equipment data to a file
    public void saveEquipmentDataToFile(String filePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write each data field to a new line in the file
            writer.write(name);
            writer.newLine();
            writer.write(manufacturer);
            writer.newLine();
            writer.write(modelNumber);
            writer.newLine();
            writer.write(serialNumber);
            writer.newLine();
            writer.write(macAddress);
            writer.newLine();
            writer.write(currentIPAddress);
            writer.newLine();
            writer.write(previousIPAddress);
            writer.newLine();
            writer.write(currentLocation);
            writer.newLine();
            writer.write(previousLocation);
        }
    }

    @Override
    public String toString() {
        // Convert the lastConnected date to a string representation
        String lastConnectedString = (lastConnected != null) ? lastConnected.toString() : "N/A";

        // Create a formatted string representation of the Equipment object
        return "Name: " + name + "\n" +
                "Manufacturer: " + manufacturer + "\n" +
                "Model Number: " + modelNumber + "\n" +
                "Serial Number: " + serialNumber + "\n" +
                "MAC Address: " + macAddress + "\n" +
                "Current IP Address: " + currentIPAddress + "\n" +
                "Previous IP Address: " + previousIPAddress + "\n" +
                "Current Location: " + currentLocation + "\n" +
                "Previous Location: " + previousLocation + "\n" +
                "Last Updated: " + lastUpdated + "\n" +
                "Last Connected: " + lastConnectedString;
    }
}
